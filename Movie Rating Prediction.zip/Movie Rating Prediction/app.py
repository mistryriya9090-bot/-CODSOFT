import streamlit as st
import pandas as pd
import numpy as np
import joblib
import os
from movie_rating_prediction import load_data, preprocess_data, feature_engineering, train_and_evaluate

# Set page config
st.set_page_config(page_title="Movie Rating Predictor", layout="wide")

st.title("🎬 Indian Movie Rating Predictor")
st.write("Predict the IMDb rating of an Indian movie based on its details.")

# Sidebar for training/loading
st.sidebar.header("Model Management")
DATASET_PATH = 'IMDb Movies India.csv'

def get_model():
    if os.path.exists(DATASET_PATH):
        df = load_data(DATASET_PATH)
        df = preprocess_data(df)
        X, y = feature_engineering(df)
        results, X_test, y_test = train_and_evaluate(X, y)
        # Use Random Forest as the primary model for the app
        return results["Random Forest Regressor"]["model"], df
    return None, None

model, original_df = get_model()

if model is None:
    st.error("Please ensure 'IMDb Movies India.csv' is available in the project directory.")
else:
    st.success("Model loaded and trained successfully!")

    # Layout for inputs
    col1, col2 = st.columns(2)

    with col1:
        year = st.number_input("Release Year", min_value=1900, max_value=2025, value=2020)
        duration = st.number_input("Duration (minutes)", min_value=1, max_value=500, value=120)
        votes = st.number_input("Number of Votes", min_value=1, value=1000)

    with col2:
        genre_list = sorted(original_df['Genre'].unique().tolist())
        genre = st.selectbox("Genre", genre_list)
        
        director_list = sorted(original_df['Director'].unique().tolist())
        director = st.selectbox("Director", director_list)
        
        actor1_list = sorted(original_df['Actor 1'].unique().tolist())
        actor1 = st.selectbox("Lead Actor", actor1_list)

    # Prepare input for prediction
    if st.button("Predict Rating"):
        # We need the average ratings for the selected director and actors
        dir_avg = original_df[original_df['Director'] == director]['Rating'].mean()
        a1_avg = original_df[original_df['Actor 1'] == actor1]['Rating'].mean()
        
        # For simplicity in this demo, we'll use actor1's average for all 3 actor slots if not specified
        # or just take the mean from the training data if they are new (but here we select from list)
        a2_avg = original_df['Rating'].mean() # Defaulting to global mean for simplicity
        a3_avg = original_df['Rating'].mean()

        # Genre encoding (must match training encoding)
        from sklearn.preprocessing import LabelEncoder
        le = LabelEncoder()
        le.fit(original_df['Genre'])
        genre_encoded = le.transform([genre])[0]

        input_data = pd.DataFrame([{
            'Year': year,
            'Duration': duration,
            'Votes': votes,
            'Director_Avg_Rating': dir_avg,
            'Actor1_Avg_Rating': a1_avg,
            'Actor2_Avg_Rating': a2_avg,
            'Actor3_Avg_Rating': a3_avg,
            'Genre_Encoded': genre_encoded
        }])

        prediction = model.predict(input_data)[0]
        st.metric("Predicted IMDb Rating", f"{prediction:.1f} / 10")
        
        if prediction >= 7.5:
            st.balloons()
            st.write("🌟 **Highly Rated!** This movie is likely to be a hit.")
        elif prediction >= 6.0:
            st.write("👍 **Good Rating.** This movie might perform well.")
        else:
            st.write("😐 **Average/Low Rating.** This movie might face challenges.")

st.info("Note: Predictions are based on historical performance of directors, actors, and genre trends.")
