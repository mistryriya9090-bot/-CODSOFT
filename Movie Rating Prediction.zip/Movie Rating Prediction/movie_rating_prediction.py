import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.tree import DecisionTreeRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.preprocessing import LabelEncoder
import os

def load_data(file_path):
    """Loads the dataset from the given path."""
    if not os.path.exists(file_path):
        print(f"Error: Dataset not found at {file_path}")
        return None
    # Dataset is likely in Latin-1 or similar encoding
    try:
        df = pd.read_csv(file_path, encoding='latin-1')
    except Exception as e:
        print(f"Error reading CSV: {e}")
        return None
    return df

def preprocess_data(df):
    """Preprocesses the movie dataset."""
    if df is None:
        return None
    
    print("Initial Data Shape:", df.shape)
    
    # Drop rows where Rating is missing (Target variable)
    df.dropna(subset=['Rating'], inplace=True)
    
    # Handle Year: Remove brackets and convert to int
    df['Year'] = df['Year'].astype(str).str.extract('(\d+)').astype(float)
    
    # Handle Duration: Remove ' min' and convert to float
    df['Duration'] = df['Duration'].astype(str).str.extract('(\d+)').astype(float)
    
    # Handle Votes: Remove commas and convert to float
    df['Votes'] = df['Votes'].astype(str).str.replace(',', '').astype(float)
    
    # Split Genres and multi-actor columns for later or just handle missing
    df['Genre'] = df['Genre'].fillna('Unknown')
    df['Director'] = df['Director'].fillna('Unknown')
    df['Actor 1'] = df['Actor 1'].fillna('Unknown')
    df['Actor 2'] = df['Actor 2'].fillna('Unknown')
    df['Actor 3'] = df['Actor 3'].fillna('Unknown')
    
    # Fill missing Duration and Votes with median
    df['Duration'] = df['Duration'].fillna(df['Duration'].median())
    df['Votes'] = df['Votes'].fillna(df['Votes'].median())
    df['Year'] = df['Year'].fillna(df['Year'].median())
    
    print("Data Shape after dropping missing ratings:", df.shape)
    return df

def feature_engineering(df):
    """Encodes categorical features and prepares them for modeling."""
    if df is None:
        return None
    
    # We'll use the average rating per director and actor as features
    director_mean_rating = df.groupby('Director')['Rating'].transform('mean')
    df['Director_Avg_Rating'] = director_mean_rating
    
    actor1_mean_rating = df.groupby('Actor 1')['Rating'].transform('mean')
    df['Actor1_Avg_Rating'] = actor1_mean_rating
    
    actor2_mean_rating = df.groupby('Actor 2')['Rating'].transform('mean')
    df['Actor2_Avg_Rating'] = actor2_mean_rating
    
    actor3_mean_rating = df.groupby('Actor 3')['Rating'].transform('mean')
    df['Actor3_Avg_Rating'] = actor3_mean_rating
    
    # For Genre, we could use one-hot or target encoding.
    # For now, let's use Label Encoding for simplicity in this baseline.
    le = LabelEncoder()
    df['Genre_Encoded'] = le.fit_transform(df['Genre'])
    
    features = ['Year', 'Duration', 'Votes', 'Director_Avg_Rating', 
                'Actor1_Avg_Rating', 'Actor2_Avg_Rating', 'Actor3_Avg_Rating', 'Genre_Encoded']
    X = df[features]
    y = df['Rating']
    
    return X, y

def train_and_evaluate(X, y):
    """Trains multiple regression models and evaluates them."""
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    models = {
        "Linear Regression": LinearRegression(),
        "Decision Tree Regressor": DecisionTreeRegressor(random_state=42),
        "Random Forest Regressor": RandomForestRegressor(n_estimators=100, random_state=42),
        "Gradient Boosting Regressor": GradientBoostingRegressor(n_estimators=100, random_state=42)
    }
    
    results = {}
    for name, model in models.items():
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)
        
        mae = mean_absolute_error(y_test, y_pred)
        mse = mean_squared_error(y_test, y_pred)
        r2 = r2_score(y_test, y_pred)
        
        results[name] = {"MAE": mae, "MSE": mse, "R2": r2, "model": model, "y_pred": y_pred}
        print(f"\nModel: {name}")
        print(f"MAE: {mae:.4f}")
        print(f"MSE: {mse:.4f}")
        print(f"R2 Score: {r2:.4f}")
        
    return results, X_test, y_test

def plot_results(results, X_test, y_test):
    """Generates and saves feature importance and actual vs predicted plots."""
    if not results:
        return
    
    # Take the best model (e.g., Random Forest or Gradient Boosting)
    # For now, let's use Random Forest for importance plotting
    rf_data = results.get("Random Forest Regressor")
    if rf_data:
        model = rf_data["model"]
        importance = model.feature_importances_
        feature_names = X_test.columns
        
        plt.figure(figsize=(10, 6))
        sns.barplot(x=importance, y=feature_names)
        plt.title("Feature Importance (Random Forest)")
        plt.xlabel("Importance Score")
        plt.ylabel("Features")
        plt.tight_layout()
        plt.savefig("feature_importance.png")
        print("Feature importance plot saved as feature_importance.png")

    # Predicted vs Actual for Linear Regression
    lr_data = results.get("Linear Regression")
    if lr_data:
        y_pred = lr_data["y_pred"]
        plt.figure(figsize=(10, 6))
        plt.scatter(y_test, y_pred, alpha=0.5)
        plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'r--', lw=2)
        plt.title("Actual vs Predicted Ratings (Linear Regression)")
        plt.xlabel("Actual Ratings")
        plt.ylabel("Predicted Ratings")
        plt.tight_layout()
        plt.savefig("actual_vs_predicted.png")
        print("Actual vs Predicted plot saved as actual_vs_predicted.png")

if __name__ == "__main__":
    DATASET_PATH = 'IMDb Movies India.csv' # Assuming this will be the file name
    
    # Load
    movie_df = load_data(DATASET_PATH)
    
    if movie_df is not None:
        # Preprocess
        movie_df = preprocess_data(movie_df)
        
        # Feature Engineering
        X, y = feature_engineering(movie_df)
        
        # Train & Evaluate
        results, X_test, y_test = train_and_evaluate(X, y)
        
        # Plot
        plot_results(results, X_test, y_test)
    else:
        print("Please ensure the dataset file 'IMDb Movies India.csv' is in the current directory.")
