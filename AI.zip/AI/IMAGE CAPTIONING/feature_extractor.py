import os
import pickle
import numpy as np
from tqdm import tqdm
from tensorflow.keras.applications.resnet50 import ResNet50, preprocess_input
from tensorflow.keras.preprocessing.image import load_img, img_to_array
from tensorflow.keras.models import Model

def extract_features(directory):
    """Extracting features from each image in the directory"""
    # Loading ResNet50 model (pre-trained on ImageNet)
    # Removing the top (classification) layer to get features
    model = ResNet50(weights='imagenet')
    model = Model(inputs=model.inputs, outputs=model.layers[-2].output)
    print(model.summary())
    
    features = dict()
    
    # List all files
    image_files = os.listdir(directory)
    print(f"Total images found: {len(image_files)}")
    
    for name in tqdm(image_files):
        # Path to image
        filename = os.path.join(directory, name)
        # Load image (ResNet50 expects 224x224)
        image = load_img(filename, target_size=(224, 224))
        # Convert to array
        image = img_to_array(image)
        # Reshape to (1, 224, 224, 3)
        image = image.reshape((1, image.shape[0], image.shape[1], image.shape[2]))
        # Preprocess for ResNet50
        image = preprocess_input(image)
        # Feature extraction
        feature = model.predict(image, verbose=0)
        # Image ID (removing extension)
        image_id = name.split('.')[0]
        # Store feature (flattened 2048-dim vector)
        features[image_id] = feature
        
    return features

# --- Configuration ---
DATASET_PATH = r"C:\Users\mistr\.cache\kagglehub\datasets\adityajn105\flickr8k\versions\1"
IMAGES_DIR = os.path.join(DATASET_PATH, "Images")

if __name__ == "__main__":
    print("Starting feature extraction (this may take time on CPU)...")
    # For demo purposes, we could limit this to a subset, 
    # but the user asked for the system, so we'll try the full set.
    features = extract_features(IMAGES_DIR)
    print(f"Extracted {len(features)} image features.")
    
    # Save to file
    with open("features.pkl", "wb") as f:
        pickle.dump(features, f)
    print("Saved 'features.pkl'")
