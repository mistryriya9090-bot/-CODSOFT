def chatbot():
    print("Chatbot: Hello! I am your simple rule-based AI chatbot.")
    print("Chatbot: You can start chatting with me, or type 'bye' to exit.")

    while True:
        # Get user input and clean it
        user_input = input("You: ").strip().lower()

        # Rule 1: Greeting
        if user_input == "hello" or user_input == "hi":
            print("Chatbot: Hi there! How can I help you today?")
        
        # Rule 2: Status Check
        elif user_input == "how are you?" or user_input == "how are you":
            print("Chatbot: I'm doing great, thank you for asking! How about you?")
        
        # Rule 3: Name / Identity
        elif user_input == "what is your name?" or user_input == "what is your name":
            print("Chatbot: I'm a simple rule-based chatbot created to assist you.")
        
        # Rule 4: Exit message
        elif user_input == "bye" or user_input == "exit":
            print("Chatbot: Goodbye! Have a great day!")
            break
        
        # Default response for unknown input
        else:
            print("Chatbot: I'm sorry, I don't understand that. Could you try asking something else?")

if __name__ == "__main__":
    chatbot()
