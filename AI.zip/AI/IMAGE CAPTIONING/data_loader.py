import os
import string
import pickle

def load_doc(filename):
    """Loading the file as text"""
    with open(filename, 'r') as file:
        text = file.read()
    return text

def load_descriptions(doc):
    """Mapping images to captions"""
    mapping = dict()
    # skipping the header
    lines = doc.split('\n')[1:]
    for line in lines:
        if len(line) < 2:
            continue
        tokens = line.split(',')
        image_id, image_desc = tokens[0], tokens[1:]
        
        # joining if description contains comma
        image_desc = " ".join(image_desc)
        
        # removing extension from image_id (e.g. 1000268201_693b08cb0e.jpg -> 1000268201_693b08cb0e)
        image_id = image_id.split('.')[0]
        
        if image_id not in mapping:
            mapping[image_id] = list()
        mapping[image_id].append(image_desc)
    return mapping

def clean_descriptions(descriptions):
    """Text cleaning: lowercase, remove punctuation, digits, single chars"""
    table = str.maketrans('', '', string.punctuation)
    for key, desc_list in descriptions.items():
        for i in range(len(desc_list)):
            desc = desc_list[i]
            # tokenize
            desc = desc.split()
            # to lower case
            desc = [word.lower() for word in desc]
            # remove punctuation from each token
            desc = [w.translate(table) for w in desc]
            # remove hanging 's' and 'a' (single chars)
            desc = [word for word in desc if len(word) > 1]
            # remove tokens with numbers
            desc = [word for word in desc if word.isalpha()]
            # store as string
            desc_list[i] = 'startseq ' + ' '.join(desc) + ' endseq'

# --- Configuration ---
DATASET_PATH = r"C:\Users\mistr\.cache\kagglehub\datasets\adityajn105\flickr8k\versions\1"
CAPTIONS_FILE = os.path.join(DATASET_PATH, "captions.txt")

if __name__ == "__main__":
    print("Loading captions...")
    doc = load_doc(CAPTIONS_FILE)
    descriptions = load_descriptions(doc)
    print(f"Loaded {len(descriptions)} images with captions.")
    
    print("Cleaning captions...")
    clean_descriptions(descriptions)
    
    # Vocabulary building
    vocab = set()
    for key in descriptions.keys():
        [vocab.update(d.split()) for d in descriptions[key]]
    print(f"Vocabulary size: {len(vocab)}")
    
    # Save processed descriptions
    with open("descriptions.pkl", "wb") as f:
        pickle.dump(descriptions, f)
    print("Saved 'descriptions.pkl'")
    
    # Save vocabulary for later use
    with open("vocab.pkl", "wb") as f:
        pickle.dump(vocab, f)
    print("Saved 'vocab.pkl'")
