import pickle
import numpy as np
from tensorflow.keras.layers import Input, Dense, LSTM, Embedding, Dropout, add
from tensorflow.keras.models import Model
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.utils import to_categorical

def define_model(vocab_size, max_length):
    """CNN-RNN Image Captioning Model"""
    
    # Feature extractor (CNN)
    inputs1 = Input(shape=(2048,))
    fe1 = Dropout(0.5)(inputs1)
    fe2 = Dense(256, activation='relu')(fe1)
    
    # Sequence processor (RNN)
    inputs2 = Input(shape=(max_length,))
    se1 = Embedding(vocab_size, 256, mask_zero=True)(inputs2)
    se2 = Dropout(0.5)(se1)
    se3 = LSTM(256)(se2)
    
    # Decoder
    decoder1 = add([fe2, se3])
    decoder2 = Dense(256, activation='relu')(decoder1)
    outputs = Dense(vocab_size, activation='softmax')(decoder2)
    
    # Model assembly
    model = Model(inputs=[inputs1, inputs2], outputs=outputs)
    model.compile(loss='categorical_crossentropy', optimizer='adam')
    
    # Summary
    print(model.summary())
    return model

def get_max_length(descriptions):
    """Calculate the max length of a description"""
    all_desc = []
    for key in descriptions.keys():
        [all_desc.append(d) for d in descriptions[key]]
    return max(len(d.split()) for d in all_desc)

if __name__ == "__main__":
    # Load metadata for smoke test
    with open("vocab.pkl", "rb") as f:
        vocab = pickle.load(f)
    with open("descriptions.pkl", "rb") as f:
        descriptions = pickle.load(f)
        
    vocab_size = len(vocab) + 1 # +1 for padding index 0
    max_length = get_max_length(descriptions)
    
    print(f"Vocabulary Size: {vocab_size}")
    print(f"Max Description Length: {max_length}")
    
    model = define_model(vocab_size, max_length)
    print("Model architecture defined successfully.")
