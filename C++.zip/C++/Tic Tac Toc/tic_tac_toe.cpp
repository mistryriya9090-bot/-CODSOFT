#include <iostream>
#include <vector>

using namespace std;

// Function to display the board
void displayBoard(const char board[3][3]) {
    cout << "\n";
    for (int i = 0; i < 3; i++) {
        cout << " ";
        for (int j = 0; j < 3; j++) {
            cout << board[i][j];
            if (j < 2) cout << " | ";
        }
        cout << "\n";
        if (i < 2) cout << "-----------" << "\n";
    }
    cout << "\n";
}

// Function to initialize the board with spaces
void initializeBoard(char board[3][3]) {
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            board[i][j] = ' ';
        }
    }
}

// Function to check for a win
bool checkWin(const char board[3][3], char player) {
    // Check rows and columns
    for (int i = 0; i < 3; i++) {
        if ((board[i][0] == player && board[i][1] == player && board[i][2] == player) ||
            (board[0][i] == player && board[1][i] == player && board[2][i] == player)) {
            return true;
        }
    }
    // Check diagonals
    if ((board[0][0] == player && board[1][1] == player && board[2][2] == player) ||
        (board[0][2] == player && board[1][1] == player && board[2][0] == player)) {
        return true;
    }
    return false;
}

// Function to check for a draw
bool checkDraw(const char board[3][3]) {
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            if (board[i][j] == ' ') return false;
        }
    }
    return true;
}

int main() {
    char board[3][3];
    char currentPlayer = 'X';
    bool gameWon = false;
    bool gameDraw = false;
    char playAgain;

    do {
        initializeBoard(board);
        currentPlayer = 'X';
        gameWon = false;
        gameDraw = false;

        cout << "Welcome to Tic-Tac-Toe!\n";
        cout << "Player 1 (X)  -  Player 2 (O)\n";

        while (true) {
            displayBoard(board);

            int row, col;
            cout << "Player " << currentPlayer << ", enter your move (row and column 1-3): ";
            cin >> row >> col;

            // Validate input
            if (row < 1 || row > 3 || col < 1 || col > 3 || board[row - 1][col - 1] != ' ') {
                cout << "Invalid move! Please try again.\n";
                // Clear buffer in case of non-integer input
                cin.clear();
                cin.ignore(1000, '\n');
                continue;
            }

            // Update board
            board[row - 1][col - 1] = currentPlayer;

            // Check win/draw
            if (checkWin(board, currentPlayer)) {
                displayBoard(board);
                cout << "Congratulations! Player " << currentPlayer << " wins!\n";
                gameWon = true;
                break;
            } else if (checkDraw(board)) {
                displayBoard(board);
                cout << "It's a draw!\n";
                gameDraw = true;
                break;
            }

            // Switch player
            currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
        }

        cout << "Do you want to play again? (y/n): ";
        cin >> playAgain;

    } while (playAgain == 'y' || playAgain == 'Y');

    cout << "Thanks for playing!\n";

    return 0;
}
