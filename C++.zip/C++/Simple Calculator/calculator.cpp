#include <iostream>
#include <limits>
#include <string>

using namespace std;

// Function prototypes
void displayMenu();
double getNumber(string prompt);
int getMenuChoice();
double add(double a, double b);
double subtract(double a, double b);
double multiply(double a, double b);
double divide(double a, double b);

int main() {
    char continueCalc = 'y';

    cout << "========================================" << endl;
    cout << "       Simple C++ Calculator            " << endl;
    cout << "========================================" << endl;

    while (continueCalc == 'y' || continueCalc == 'Y') {
        double num1 = getNumber("Enter first numeric value: ");
        double num2 = getNumber("Enter second numeric value: ");

        displayMenu();
        int choice = getMenuChoice();

        double result = 0;
        bool validOperation = true;

        switch (choice) {
            case 1:
                result = add(num1, num2);
                cout << "\nResult: " << num1 << " + " << num2 << " = " << result << endl;
                break;
            case 2:
                result = subtract(num1, num2);
                cout << "\nResult: " << num1 << " - " << num2 << " = " << result << endl;
                break;
            case 3:
                result = multiply(num1, num2);
                cout << "\nResult: " << num1 << " * " << num2 << " = " << result << endl;
                break;
            case 4:
                if (num2 == 0) {
                    cout << "\nError: Division by zero is not allowed." << endl;
                    validOperation = false;
                } else {
                    result = divide(num1, num2);
                    cout << "\nResult: " << num1 << " / " << num2 << " = " << result << endl;
                }
                break;
            default:
                cout << "\nInvalid operation selected." << endl;
                validOperation = false;
                break;
        }

        cout << "\nDo you want to perform another calculation? (y/n): ";
        cin >> continueCalc;
        
        // Clear the buffer
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "----------------------------------------" << endl;
    }

    cout << "Thank you for using the Simple Calculator. Goodbye!" << endl;

    return 0;
}

void displayMenu() {
    cout << "\nSelect an operation:" << endl;
    cout << "1. Addition (+)" << endl;
    cout << "2. Subtraction (-)" << endl;
    cout << "3. Multiplication (*)" << endl;
    cout << "4. Division (/)" << endl;
}

double getNumber(string prompt) {
    double value;
    while (true) {
        cout << prompt;
        if (cin >> value) {
            return value;
        } else {
            cout << "Invalid input. Please enter a numeric value." << endl;
            cin.clear(); // clear error flags
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // discard invalid input
        }
    }
}

int getMenuChoice() {
    int choice;
    while (true) {
        cout << "Enter your choice (1-4): ";
        if (cin >> choice && choice >= 1 && choice <= 4) {
            return choice;
        } else {
            cout << "Invalid choice. Please select a valid option from the menu (1-4)." << endl;
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
    }
}

double add(double a, double b) {
    return a + b;
}

double subtract(double a, double b) {
    return a - b;
}

double multiply(double a, double b) {
    return a * b;
}

double divide(double a, double b) {
    return a / b;
}
