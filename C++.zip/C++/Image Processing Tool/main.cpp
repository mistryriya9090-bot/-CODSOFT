#include <opencv2/opencv.hpp>
#include <iostream>
#include <string>
#include <vector>

using namespace std;
using namespace cv;

// Function prototypes
void displayMenu();
Mat loadImage(const string& path);
void displayImage(const string& windowName, const Mat& img);
void applyGrayscale(Mat& img);
void applyBlur(Mat& img);
void applySharpen(Mat& img);
void adjustBrightnessContrast(Mat& img, double alpha, int beta);
void cropImage(Mat& img);
void resizeImage(Mat& img);
bool saveImage(const string& path, const Mat& img);

int main() {
    Mat currentImage;
    string currentPath = "";
    int choice;

    cout << "========================================" << endl;
    cout << "   Welcome to Image Processing Tool     " << endl;
    cout << "========================================" << endl;

    while (true) {
        displayMenu();
        if (!(cin >> choice)) {
            cout << "Invalid input. Please enter a number." << endl;
            cin.clear();
            cin.ignore(1000, '\n');
            continue;
        }

        switch (choice) {
            case 1: { // Load Image
                cout << "Enter image path (e.g., sample.jpg or D:/imgs/test.png): ";
                cin >> currentPath;
                currentImage = loadImage(currentPath);
                if (!currentImage.empty()) {
                    cout << "Image loaded successfully! Size: " << currentImage.cols << "x" << currentImage.rows << endl;
                    displayImage("Current Image", currentImage);
                }
                break;
            }
            case 2: { // Display Image
                if (currentImage.empty()) {
                    cout << "No image loaded. Please load an image first." << endl;
                } else {
                    displayImage("Current Image", currentImage);
                }
                break;
            }
            case 3: { // Apply Grayscale
                if (currentImage.empty()) {
                    cout << "No image loaded." << endl;
                } else {
                    applyGrayscale(currentImage);
                    cout << "Grayscale filter applied." << endl;
                    displayImage("Current Image", currentImage);
                }
                break;
            }
            case 4: { // Apply Blur
                if (currentImage.empty()) {
                    cout << "No image loaded." << endl;
                } else {
                    applyBlur(currentImage);
                    cout << "Blur effect applied." << endl;
                    displayImage("Current Image", currentImage);
                }
                break;
            }
            case 5: { // Adjust Brightness/Contrast
                if (currentImage.empty()) {
                    cout << "No image loaded." << endl;
                } else {
                    double alpha = 1.0;
                    int beta = 0;
                    cout << "Enter contrast value (1.0-3.0 for more contrast): ";
                    cin >> alpha;
                    cout << "Enter brightness value (0-100 for more brightness): ";
                    cin >> beta;
                    adjustBrightnessContrast(currentImage, alpha, beta);
                    cout << "Adjustments applied." << endl;
                    displayImage("Current Image", currentImage);
                }
                break;
            }
            case 6: { // Crop Image
                if (currentImage.empty()) {
                    cout << "No image loaded." << endl;
                } else {
                    cropImage(currentImage);
                    displayImage("Current Image", currentImage);
                }
                break;
            }
            case 7: { // Resize Image
                if (currentImage.empty()) {
                    cout << "No image loaded." << endl;
                } else {
                    resizeImage(currentImage);
                    displayImage("Current Image", currentImage);
                }
                break;
            }
            case 8: { // Save Image
                if (currentImage.empty()) {
                    cout << "No image loaded." << endl;
                } else {
                    string savePath;
                    cout << "Enter filename to save (e.g., processed.jpg): ";
                    cin >> savePath;
                    if (saveImage(savePath, currentImage)) {
                        cout << "Image saved successfully to " << savePath << endl;
                    } else {
                        cout << "Error saving image!" << endl;
                    }
                }
                break;
            }
            case 9: { // Exit
                cout << "Exiting program. Goodbye!" << endl;
                return 0;
            }
            case 0: { // Extra: Sharpen
                if (currentImage.empty()) {
                    cout << "No image loaded." << endl;
                } else {
                    applySharpen(currentImage);
                    cout << "Sharpen filter applied." << endl;
                    displayImage("Current Image", currentImage);
                }
                break;
            }
            default:
                cout << "Invalid choice. Please try again." << endl;
        }
    }
    return 0;
}

void displayMenu() {
    cout << "\n----------- MENU -----------" << endl;
    cout << "1. Load Image" << endl;
    cout << "2. Display Image" << endl;
    cout << "3. Apply Grayscale" << endl;
    cout << "4. Apply Blur" << endl;
    cout << "5. Adjust Brightness/Contrast" << endl;
    cout << "6. Crop Image" << endl;
    cout << "7. Resize Image" << endl;
    cout << "8. Save Image" << endl;
    cout << "0. Apply Sharpen (Extra)" << endl;
    cout << "9. Exit" << endl;
    cout << "Choice: ";
}

Mat loadImage(const string& path) {
    Mat img = imread(path);
    if (img.empty()) {
        cout << "Error: Could not open or find the image at " << path << endl;
    }
    return img;
}

void displayImage(const string& windowName, const Mat& img) {
    imshow(windowName, img);
    waitKey(1); // Brief pause to render window
}

void applyGrayscale(Mat& img) {
    if (img.channels() > 1) {
        cvtColor(img, img, COLOR_BGR2GRAY);
    }
}

void applyBlur(Mat& img) {
    GaussianBlur(img, img, Size(7, 7), 0);
}

void applySharpen(Mat& img) {
    Mat kernel = (Mat_<char>(3, 3) <<  0, -1,  0,
                                     -1,  5, -1,
                                      0, -1,  0);
    filter2D(img, img, img.depth(), kernel);
}

void adjustBrightnessContrast(Mat& img, double alpha, int beta) {
    img.convertTo(img, -1, alpha, beta);
}

void cropImage(Mat& img) {
    int x, y, w, h;
    cout << "Current size: " << img.cols << "x" << img.rows << endl;
    cout << "Enter X Y Width Height (space separated): ";
    cin >> x >> y >> w >> h;

    // Bounds checking
    if (x < 0 || y < 0 || x + w > img.cols || y + h > img.rows) {
        cout << "Error: Crop region out of bounds!" << endl;
        return;
    }

    Rect roi(x, y, w, h);
    img = img(roi).clone(); // Clone to ensure independence
    cout << "Image cropped to " << w << "x" << h << endl;
}

void resizeImage(Mat& img) {
    int w, h;
    cout << "Enter new Width and Height (space separated): ";
    cin >> w >> h;
    if (w <= 0 || h <= 0) {
        cout << "Invalid dimensions!" << endl;
        return;
    }
    resize(img, img, Size(w, h), 0, 0, INTER_LINEAR);
    cout << "Image resized to " << w << "x" << h << endl;
}

bool saveImage(const string& path, const Mat& img) {
    return imwrite(path, img);
}
