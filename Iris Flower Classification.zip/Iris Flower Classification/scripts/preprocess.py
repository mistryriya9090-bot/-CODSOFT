import pandas as pd
from sklearn.preprocessing import LabelEncoder
import os

def load_and_preprocess_data(filepath="data/Iris.csv"):
    # Load the dataset
    df = pd.read_csv(filepath)
    
    # Kaggle dataset usually has: sepal.length, sepal.width, petal.length, petal.width, variety
    # Some versions have: sepal_length, sepal_width, petal_length, petal_width, species
    # Let's handle different column naming
    column_mapping = {
        'sepal.length': 'SepalLengthCm',
        'sepal.width': 'SepalWidthCm',
        'petal.length': 'PetalLengthCm',
        'petal.width': 'PetalWidthCm',
        'variety': 'Species'
    }
    df = df.rename(columns=column_mapping)
    
    # Check for missing values
    print("Missing values per column:\n", df.isnull().sum())
    
    # Encoding the target variable (Species)
    le = LabelEncoder()
    df['Species_Encoded'] = le.fit_transform(df['Species'])
    
    return df, le

if __name__ == "__main__":
    if not os.path.exists("data/Iris.csv"):
        print("Data file not found.")
    else:
        df, le = load_and_preprocess_data()
        print("\nDataset Info:\n", df.info())
        print("\nFirst 5 rows:\n", df.head())
        print("\nSpecies Mapping:")
        for i, species in enumerate(le.classes_):
            print(f"{i}: {species}")
