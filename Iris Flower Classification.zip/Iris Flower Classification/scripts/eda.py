import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from scripts.preprocess import load_and_preprocess_data

def perform_eda():
    df, le = load_and_preprocess_data()
    
    # Setting the aesthetic style of the plots
    sns.set(style="whitegrid")
    
    # Pairplot to see relationships
    plt.figure(figsize=(10, 8))
    pairplot = sns.pairplot(df.drop('Species_Encoded', axis=1), hue="Species", diag_kind="kde")
    pairplot.savefig("notebooks/pairplot.png")
    plt.close()
    
    # Box plots for each feature
    plt.figure(figsize=(12, 6))
    features = ['SepalLengthCm', 'SepalWidthCm', 'PetalLengthCm', 'PetalWidthCm']
    for i, feature in enumerate(features):
        plt.subplot(2, 2, i+1)
        sns.boxplot(x='Species', y=feature, data=df)
        plt.title(f'{feature} by Species')
    plt.tight_layout()
    plt.savefig("notebooks/boxplots.png")
    plt.close()
    
    # Correlation Matrix
    plt.figure(figsize=(8, 6))
    corr = df[features].corr()
    sns.heatmap(corr, annot=True, cmap='coolwarm', fmt=".2f")
    plt.title("Feature Correlation Matrix")
    plt.savefig("notebooks/correlation_matrix.png")
    plt.close()
    
    print("EDA Visualizations saved in 'notebooks/' directory.")

if __name__ == "__main__":
    perform_eda()
