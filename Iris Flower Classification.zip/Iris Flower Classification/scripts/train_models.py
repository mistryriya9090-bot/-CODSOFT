import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import joblib
import os
from scripts.preprocess import load_and_preprocess_data

def train_and_evaluate():
    df, le = load_and_preprocess_data()
    
    features = ['SepalLengthCm', 'SepalWidthCm', 'PetalLengthCm', 'PetalWidthCm']
    X = df[features]
    y = df['Species_Encoded']
    
    # Train-test split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
    
    models = {
        "Logistic Regression": LogisticRegression(max_iter=200),
        "KNN": KNeighborsClassifier(),
        "Decision Tree": DecisionTreeClassifier(),
        "Random Forest": RandomForestClassifier(),
        "SVM": SVC(probability=True)
    }
    
    best_model = None
    best_accuracy = 0
    results = {}

    if not os.path.exists("models"):
        os.makedirs("models")

    print("\n--- Model Evaluation ---")
    for name, model in models.items():
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)
        acc = accuracy_score(y_test, y_pred)
        results[name] = acc
        print(f"{name} Accuracy: {acc:.4f}")
        
        if acc > best_accuracy:
            best_accuracy = acc
            best_model = (name, model)
            
    print(f"\nBest Model: {best_model[0]} with Accuracy: {best_accuracy:.4f}")
    
    # Save the best model and encoder
    joblib.dump(best_model[1], "models/best_model.pkl")
    joblib.dump(le, "models/label_encoder.pkl")
    print("Best model and label encoder saved in 'models/' directory.")
    
    # Detailed report for the best model
    y_pred_best = best_model[1].predict(X_test)
    print(f"\nClassification Report for {best_model[0]}:")
    print(classification_report(y_test, y_pred_best, target_names=le.classes_))
    
    return results

if __name__ == "__main__":
    train_and_evaluate()
