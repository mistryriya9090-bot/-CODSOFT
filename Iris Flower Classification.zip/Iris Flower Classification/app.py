import streamlit as st
import pandas as pd
import joblib
import numpy as np

# Set page config
st.set_page_config(
    page_title="Iris Species Predictor",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for premium styling
st.markdown("""
<style>
    .main {
        background-color: #1a1a2e;
        color: #ffffff;
    }
    .stApp {
        background: linear-gradient(135deg, #0f1624 0%, #1a2a4a 100%);
        color: #ffffff;
    }
    /* Target all headers and subheaders for white color */
    h1, h2, h3, h4, h5, h6, .stMarkdown p {
        color: #ffffff !important;
    }
    .sidebar .sidebar-content {
        background: rgba(255, 255, 255, 0.05);
        backdrop-filter: blur(10px);
        color: #ffffff;
    }
    .prediction-card {
        background: rgba(255, 255, 255, 0.1);
        padding: 2rem;
        border-radius: 15px;
        box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
        backdrop-filter: blur(4px);
        -webkit-backdrop-filter: blur(4px);
        border: 1px solid rgba(255, 255, 255, 0.18);
        text-align: center;
        color: #ffffff;
    }
    .prediction-title {
        font-size: 2.5rem;
        font-weight: 700;
        margin-bottom: 1rem;
        background: linear-gradient(90deg, #4facfe 0%, #00f2fe 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }
    .metric-card {
        background: rgba(255, 255, 255, 0.05);
        padding: 1rem;
        border-radius: 10px;
        margin: 5px;
        border: 1px solid rgba(255, 255, 255, 0.1);
    }
</style>
""", unsafe_allow_html=True)

# App Title
st.title("🌺 Iris Flower Classification")
st.markdown("---")

# Load models
@st.cache_resource
def load_models():
    model = joblib.load("models/best_model.pkl")
    encoder = joblib.load("models/label_encoder.pkl")
    return model, encoder

try:
    model, encoder = load_models()
    
    # Sidebar for inputs
    st.sidebar.header("🌷 Input Features")
    sepal_length = st.sidebar.slider("Sepal Length (cm)", 4.0, 8.0, 5.8)
    sepal_width = st.sidebar.slider("Sepal Width (cm)", 2.0, 4.5, 3.0)
    petal_length = st.sidebar.slider("Petal Length (cm)", 1.0, 7.0, 4.3)
    petal_width = st.sidebar.slider("Petal Width (cm)", 0.1, 2.5, 1.3)

    # Prediction
    features = np.array([[sepal_length, sepal_width, petal_length, petal_width]])
    prediction = model.predict(features)
    prediction_proba = model.predict_proba(features)
    species_name = encoder.inverse_transform(prediction)[0]

    # Main area display
    col1, col2 = st.columns([1, 1])

    with col1:
        st.markdown(f"""
        <div class="prediction-card">
            <h3>Prediction Result</h3>
            <div class="prediction-title">{species_name}</div>
            <p>Model Confidence: {prediction_proba[0][prediction[0]]:.2%}</p>
        </div>
        """, unsafe_allow_html=True)

    with col2:
        st.subheader("📊 Prediction Probabilities")
        proba_df = pd.DataFrame(
            prediction_proba, 
            columns=encoder.classes_,
            index=["Probability"]
        ).T.sort_values(by="Probability", ascending=False)
        st.bar_chart(proba_df)

    # Details about the species
    st.markdown("---")
    st.subheader(f"About Iris {species_name}")
    descriptions = {
        "Setosa": "Iris setosa is an iris species that is native to the Russian Arctic and Subarctic regions, and the Aleutian Islands.",
        "Versicolor": "Iris versicolor is also known as the blue flag or larger blue flag. It is native to North America.",
        "Virginica": "Iris virginica is a perennial plant native to eastern North America."
    }
    st.write(descriptions.get(species_name, "Information not available."))

except FileNotFoundError:
    st.error("Model files not found. Please run individual training scripts first.")
