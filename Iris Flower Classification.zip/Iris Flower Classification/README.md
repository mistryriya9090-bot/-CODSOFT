# Iris Flower Classification

A machine learning project to classify Iris flower species based on sepal and petal measurements.

## Project Structure

- `data/`: Contains the Iris dataset.
- `models/`: Saved model and label encoder.
- `notebooks/`: EDA visualizations.
- `scripts/`: Data preprocessing, EDA, and training scripts.
- `app.py`: Streamlit application.
- `requirements.txt`: Project dependencies.

## Setup & Usage

1. **Install Requirements**:
   ```bash
   pip install -r requirements.txt
   ```

2. **Run EDA**:
   ```bash
   python scripts/eda.py
   ```

3. **Train Models**:
   ```bash
   $env:PYTHONPATH = "."; python scripts/train_models.py
   ```

4. **Launch App**:
   ```bash
   streamlit run app.py
   ```
