import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.text.DecimalFormat;
import java.time.Duration;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * CurrencyConverter - A Java Swing application to convert currencies in real-time.
 * Uses Frankfurter API (frankfurter.dev) for exchange rates.
 */
public class CurrencyConverter extends JFrame {
    private static final String API_BASE = "https://api.frankfurter.app/";
    private static final String CURRENCIES_ENDPOINT = API_BASE + "currencies";
    private static final String LATEST_ENDPOINT = API_BASE + "latest?from=";

    private JComboBox<String> baseCurrencyCombo;
    private JComboBox<String> targetCurrencyCombo;
    private JTextField amountField;
    private JTextField resultBox;
    private JLabel rateLabel;
    private JButton convertButton;
    private JButton swapButton;
    private JProgressBar progressBar;
    private JLabel lastUpdatedLabel;

    private Map<String, String> currencyMap = new TreeMap<>();
    private Map<String, Double> cachedRates = new HashMap<>();
    private String currentBase = "";

    private final HttpClient httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(10))
            .build();

    private final DecimalFormat df = new DecimalFormat("#,##0.00");

    public CurrencyConverter() {
        setTitle("Currency Converter - Premium Edition");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(450, 500);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(245, 247, 250));

        initComponents();
        loadCurrencies();
    }

    private void initComponents() {
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Title
        JLabel titleLabel = new JLabel("Currency Converter", JLabel.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titleLabel.setForeground(new Color(44, 62, 80));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        add(titleLabel, gbc);

        // Amount Input
        JLabel amountLabel = new JLabel("Amount");
        amountLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        gbc.gridy = 1; gbc.gridwidth = 2;
        add(amountLabel, gbc);

        amountField = new JTextField("1.00");
        amountField.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        amountField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        gbc.gridy = 2;
        add(amountField, gbc);

        // Base Currency
        JLabel fromLabel = new JLabel("From");
        fromLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        gbc.gridy = 3; gbc.gridwidth = 1;
        add(fromLabel, gbc);

        baseCurrencyCombo = new JComboBox<>();
        baseCurrencyCombo.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        gbc.gridy = 4;
        add(baseCurrencyCombo, gbc);

        // Swap Button
        swapButton = new JButton("Swap");
        swapButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        swapButton.setToolTipText("Swap Currencies");
        swapButton.setBackground(new Color(230, 126, 34));
        swapButton.setForeground(Color.WHITE);
        swapButton.setFocusPainted(false);
        swapButton.addActionListener(e -> swapCurrencies());
        gbc.gridx = 1; gbc.gridy = 4; gbc.weightx = 0.2;
        add(swapButton, gbc);

        // Target Currency
        JLabel toLabel = new JLabel("To");
        toLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        gbc.gridx = 0; gbc.gridy = 5; gbc.weightx = 1.0;
        add(toLabel, gbc);

        targetCurrencyCombo = new JComboBox<>();
        targetCurrencyCombo.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        gbc.gridy = 6;
        add(targetCurrencyCombo, gbc);

        // Progress Bar
        progressBar = new JProgressBar();
        progressBar.setIndeterminate(true);
        progressBar.setVisible(false);
        gbc.gridy = 7; gbc.gridwidth = 2;
        add(progressBar, gbc);

        // Result Box
        JLabel resultLabel = new JLabel("Resulting Amount");
        resultLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        gbc.gridy = 8; gbc.gridwidth = 2;
        add(resultLabel, gbc);

        resultBox = new JTextField("0.00");
        resultBox.setEditable(false);
        resultBox.setFont(new Font("Segoe UI", Font.BOLD, 20));
        resultBox.setBackground(Color.WHITE);
        resultBox.setForeground(new Color(41, 128, 185));
        resultBox.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        gbc.gridy = 9;
        add(resultBox, gbc);

        rateLabel = new JLabel("Latest Exchange Rate Info", JLabel.CENTER);
        rateLabel.setFont(new Font("Segoe UI", Font.ITALIC, 12));
        rateLabel.setForeground(new Color(127, 140, 141));
        gbc.gridy = 10;
        add(rateLabel, gbc);

        // last updated
        lastUpdatedLabel = new JLabel("", JLabel.CENTER);
        lastUpdatedLabel.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        gbc.gridy = 11;
        add(lastUpdatedLabel, gbc);

        // Convert Button
        convertButton = new JButton("Refresh / Convert");
        convertButton.setFont(new Font("Segoe UI", Font.BOLD, 16));
        convertButton.setBackground(new Color(39, 174, 96));
        convertButton.setForeground(Color.WHITE);
        convertButton.setFocusPainted(false);
        convertButton.addActionListener(e -> performConversion());
        gbc.gridy = 12;
        gbc.insets = new Insets(20, 10, 10, 10);
        add(convertButton, gbc);

        // Auto-conversion listeners
        amountField.addActionListener(e -> performConversion());
        baseCurrencyCombo.addActionListener(e -> performConversion());
        targetCurrencyCombo.addActionListener(e -> performConversion());
    }

    private void swapCurrencies() {
        int baseIdx = baseCurrencyCombo.getSelectedIndex();
        int targetIdx = targetCurrencyCombo.getSelectedIndex();
        if (baseIdx != -1 && targetIdx != -1) {
            baseCurrencyCombo.setSelectedIndex(targetIdx);
            targetCurrencyCombo.setSelectedIndex(baseIdx);
            performConversion();
        }
    }

    private void loadCurrencies() {
        setLoading(true);
        new SwingWorker<Map<String, String>, Void>() {
            @Override
            protected Map<String, String> doInBackground() throws Exception {
                HttpRequest request = HttpRequest.newBuilder()
                        .uri(URI.create(CURRENCIES_ENDPOINT))
                        .GET()
                        .build();
                HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
                if (response.statusCode() != 200) throw new Exception("API Error: " + response.statusCode());
                return parseJsonToMap(response.body());
            }

            @Override
            protected void done() {
                try {
                    currencyMap = get();
                    for (String code : currencyMap.keySet()) {
                        baseCurrencyCombo.addItem(code);
                        targetCurrencyCombo.addItem(code);
                    }
                    // Defaults
                    baseCurrencyCombo.setSelectedItem("USD");
                    targetCurrencyCombo.setSelectedItem("EUR");
                    setLoading(false);
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(CurrencyConverter.this, "Failed to load currencies: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    setLoading(false);
                }
            }
        }.execute();
    }

    private void performConversion() {
        String amountStr = amountField.getText().trim();
        System.out.println("DEBUG: Conversion triggered for amount: " + amountStr);
        if (amountStr.isEmpty()) return;

        double amount;
        try {
            amount = Double.parseDouble(amountStr);
            if (amount < 0) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            System.out.println("DEBUG: Invalid number format: " + amountStr);
            JOptionPane.showMessageDialog(this, "Please enter a valid positive number.", "Invalid Input", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String base = (String) baseCurrencyCombo.getSelectedItem();
        String target = (String) targetCurrencyCombo.getSelectedItem();
        System.out.println("DEBUG: Base: " + base + ", Target: " + target);

        if (base == null || target == null) return;

        if (base.equals(target)) {
            updateUI(amount, 1.0, target, base, "Same Currency");
            return;
        }

        // Check cache if base matches
        if (base.equals(currentBase) && cachedRates.containsKey(target)) {
            System.out.println("DEBUG: Using cached rate for " + target);
            updateUI(amount, cachedRates.get(target), target, base, "Cached");
            return;
        }

        fetchRatesAndConvert(base, target, amount);
    }

    private void fetchRatesAndConvert(String base, String target, double amount) {
        System.out.println("DEBUG: Fetching rates for " + base);
        setLoading(true);
        new SwingWorker<Map<String, Double>, Void>() {
            String date = "";
            @Override
            protected Map<String, Double> doInBackground() throws Exception {
                HttpRequest request = HttpRequest.newBuilder()
                        .uri(URI.create(LATEST_ENDPOINT + base))
                        .GET()
                        .build();
                HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
                System.out.println("DEBUG: API Response code: " + response.statusCode());
                if (response.statusCode() != 200) throw new Exception("API Error: " + response.statusCode());
                
                String body = response.body();
                // Extract date
                Matcher m = Pattern.compile("\"date\":\"([^\"]+)\"").matcher(body);
                if (m.find()) date = m.group(1);
                
                return parseRates(body);
            }

            @Override
            protected void done() {
                try {
                    cachedRates = get();
                    System.out.println("DEBUG: Fetched " + cachedRates.size() + " rates");
                    currentBase = base;
                    if (cachedRates.containsKey(target)) {
                        updateUI(amount, cachedRates.get(target), target, base, date);
                    } else {
                        throw new Exception("Currency " + target + " not found in rates.");
                    }
                    setLoading(false);
                } catch (Exception e) {
                    System.err.println("DEBUG: Conversion error: " + e.getMessage());
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(CurrencyConverter.this, "Conversion failed: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    setLoading(false);
                }
            }
        }.execute();
    }

    private void updateUI(double amount, double rate, String target, String base, String date) {
        double result = amount * rate;
        resultBox.setText(df.format(result) + " " + target);
        rateLabel.setText("1 " + base + " = " + rate + " " + target);
        lastUpdatedLabel.setText("Last Updated: " + date);
    }

    private void setLoading(boolean loading) {
        progressBar.setVisible(loading);
        convertButton.setEnabled(!loading);
        swapButton.setEnabled(!loading);
    }

    /**
     * Simple JSON parser to extract key-value pairs from a flat object.
     * Fits the /currencies response format.
     */
    private Map<String, String> parseJsonToMap(String json) {
        Map<String, String> map = new TreeMap<>();
        Pattern p = Pattern.compile("\"([^\"]+)\":\"([^\"]+)\"");
        Matcher m = p.matcher(json);
        while (m.find()) {
            map.put(m.group(1), m.group(2));
        }
        return map;
    }

    /**
     * Extracts rates from the nested "rates" object in the JSON.
     */
    private Map<String, Double> parseRates(String json) {
        Map<String, Double> map = new HashMap<>();
        // Find the "rates" object content
        int ratesIdx = json.indexOf("\"rates\":{");
        if (ratesIdx == -1) return map;
        String ratesPart = json.substring(ratesIdx);
        
        Pattern p = Pattern.compile("\"([A-Z]{3})\":([\\d.]+)");
        Matcher m = p.matcher(ratesPart);
        while (m.find()) {
            map.put(m.group(1), Double.parseDouble(m.group(2)));
        }
        return map;
    }

    public static void main(String[] args) {
        // Use System Look and Feel for better integration
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}

        SwingUtilities.invokeLater(() -> {
            new CurrencyConverter().setVisible(true);
        });
    }
}
