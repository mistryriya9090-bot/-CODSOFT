import sys

def get_valid_mark(subject_name):
    """Prompts the user for a valid mark between 0 and 100."""
    while True:
        try:
            mark = float(input(f"Enter marks for {subject_name} (out of 100): "))
            if 0 <= mark <= 100:
                return mark
            else:
                print("Invalid input! Marks must be between 0 and 100.")
        except ValueError:
            print("Invalid input! Please enter a numeric value.")

def calculate_grade(average):
    """Determines the grade based on the average percentage."""
    if average >= 90:
        return 'A'
    elif average >= 75:
        return 'B'
    elif average >= 60:
        return 'C'
    elif average >= 50:
        return 'D'
    else:
        return 'F'

def main():
    print("--- Student Grade Calculator ---")
    
    try:
        num_subjects = int(input("Enter the number of subjects: "))
        if num_subjects <= 0:
            print("Number of subjects must be greater than 0.")
            return
    except ValueError:
        print("Invalid input! Please enter a whole number for the number of subjects.")
        return

    marks = []
    for i in range(1, num_subjects + 1):
        mark = get_valid_mark(f"Subject {i}")
        marks.append(mark)

    total_marks = sum(marks)
    average_percentage = total_marks / num_subjects
    grade = calculate_grade(average_percentage)

    print("\n--- Results ---")
    print(f"Total Marks: {total_marks:.2f}")
    print(f"Average Percentage: {average_percentage:.2f}%")
    print(f"Assign Grade: {grade}")

if __name__ == "__main__":
    main()
