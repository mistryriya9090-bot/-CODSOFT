import java.util.Scanner;
import java.util.Random;

public class NumberGuessingGame {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();
        boolean playAgain = true;
        int totalRounds = 0;
        int totalScore = 0;

        System.out.println("Welcome to the Number Guessing Game!");

        while (playAgain) {
            totalRounds++;
            int numberToGuess = random.nextInt(100) + 1;
            int attempts = 0;
            int maxAttempts = 10;
            boolean hasGuessedCorrectly = false;

            System.out.println("\n--- Round " + totalRounds + " ---");
            System.out.println("I've picked a number between 1 and 100. You have " + maxAttempts + " attempts.");

            while (attempts < maxAttempts && !hasGuessedCorrectly) {
                attempts++;
                System.out.print("Attempt " + attempts + ": Enter your guess: ");
                
                // Validate input
                while (!scanner.hasNextInt()) {
                    System.out.println("Invalid input. Please enter a number.");
                    scanner.next();
                }
                
                int userGuess = scanner.nextInt();

                if (userGuess == numberToGuess) {
                    System.out.println("Correct! You've guessed the number in " + attempts + " attempts.");
                    hasGuessedCorrectly = true;
                    // Score is based on attempts remaining
                    totalScore += (maxAttempts - attempts + 1);
                } else if (userGuess > numberToGuess) {
                    System.out.println("Too high");
                } else {
                    System.out.println("Too low");
                }
            }

            if (!hasGuessedCorrectly) {
                System.out.println("Sorry! You've run out of attempts. The number was " + numberToGuess + ".");
            }

            System.out.print("Do you want to play another round? (yes/no): ");
            String response = scanner.next().toLowerCase();
            playAgain = response.startsWith("y");
        }

        System.out.println("\nGame Over!");
        System.out.println("Total Rounds Played: " + totalRounds);
        System.out.println("Total Score: " + totalScore);
        System.out.println("Thanks for playing!");
        
        scanner.close();
    }
}
