import json
import os
import uuid

class Task:
    def __init__(self, text, completed=False, task_id=None):
        self.task_id = task_id if task_id else str(uuid.uuid4())
        self.text = text
        self.completed = completed

    def to_dict(self):
        return {
            "id": self.task_id,
            "text": self.text,
            "completed": self.completed
        }

    @staticmethod
    def from_dict(data):
        return Task(
            text=data["text"],
            completed=data["completed"],
            task_id=data["id"]
        )


class TaskManager:
    def __init__(self, filename="tasks.json"):
        self.filename = filename
        self.tasks = []
        self.load_tasks()

    def add_task(self, text):
        if text.strip():
            task = Task(text)
            self.tasks.append(task)
            self.save_tasks()
            return task
        return None

    def delete_task(self, task_id):
        self.tasks = [t for t in self.tasks if t.task_id != task_id]
        self.save_tasks()

    def update_task(self, task_id, new_text):
        for task in self.tasks:
            if task.task_id == task_id:
                task.text = new_text
                self.save_tasks()
                return True
        return False

    def toggle_completed(self, task_id):
        for task in self.tasks:
            if task.task_id == task_id:
                task.completed = not task.completed
                self.save_tasks()
                return True
        return False

    def save_tasks(self):
        with open(self.filename, "w") as f:
            json.dump([t.to_dict() for t in self.tasks], f, indent=4)

    def load_tasks(self):
        if os.path.exists(self.filename):
            try:
                with open(self.filename, "r") as f:
                    data = json.load(f)
                    self.tasks = [Task.from_dict(t) for t in data]
            except (json.JSONDecodeError, KeyError):
                self.tasks = []
        else:
            self.tasks = []
