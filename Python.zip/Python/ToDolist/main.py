import tkinter as tk
from tkinter import messagebox, simpledialog
from todo_logic import TaskManager
import styles

class ToDoApp:
    def __init__(self, root):
        self.root = root
        self.root.title(styles.WINDOW_TITLE)
        self.root.geometry(styles.WINDOW_SIZE)
        self.root.configure(bg=styles.BG_COLOR)
        self.root.resizable(False, False)

        self.manager = TaskManager()
        self.setup_ui()
        self.refresh_task_list()

    def setup_ui(self):
        # Header
        header_frame = tk.Frame(self.root, bg=styles.BG_COLOR, pady=20)
        header_frame.pack(fill=tk.X)
        
        title_label = tk.Label(
            header_frame, 
            text="ProTask", 
            font=styles.TITLE_FONT, 
            bg=styles.BG_COLOR, 
            fg=styles.ACCENT_COLOR
        )
        title_label.pack()

        # Input Area
        input_container = tk.Frame(self.root, bg=styles.BG_COLOR, padx=20, pady=10)
        input_container.pack(fill=tk.X)

        self.task_entry = tk.Entry(
            input_container,
            font=styles.MAIN_FONT,
            bg=styles.CARD_COLOR,
            fg=styles.TEXT_COLOR,
            insertbackground=styles.TEXT_COLOR,
            borderwidth=0,
            highlightthickness=1,
            highlightbackground=styles.ACCENT_COLOR,
            relief=tk.FLAT
        )
        self.task_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 10), ipady=8)
        self.task_entry.bind("<Return>", lambda e: self.add_task())

        add_btn = tk.Button(
            input_container,
            text="Add Task",
            font=styles.SMALL_FONT,
            bg=styles.ACCENT_COLOR,
            fg=styles.BG_COLOR,
            activebackground=styles.SUCCESS_COLOR,
            relief=tk.FLAT,
            command=self.add_task,
            padx=15,
            pady=5
        )
        add_btn.pack(side=tk.RIGHT)

        # Task List Area (Scrollable)
        list_container = tk.Frame(self.root, bg=styles.BG_COLOR, padx=20, pady=10)
        list_container.pack(fill=tk.BOTH, expand=True)

        self.canvas = tk.Canvas(
            list_container, 
            bg=styles.BG_COLOR, 
            highlightthickness=0
        )
        self.scrollbar = tk.Scrollbar(
            list_container, 
            orient="vertical", 
            command=self.canvas.yview,
            bg=styles.BG_COLOR
        )
        self.scrollable_frame = tk.Frame(self.canvas, bg=styles.BG_COLOR)

        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        )

        self.canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw", width=440)
        self.canvas.configure(yscrollcommand=self.scrollbar.set)

        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")

    def add_task(self):
        text = self.task_entry.get()
        if text.strip():
            self.manager.add_task(text)
            self.task_entry.delete(0, tk.END)
            self.refresh_task_list()
        else:
            messagebox.showwarning("Empty Task", "Please enter a task description.")

    def refresh_task_list(self):
        # Clear current list
        for widget in self.scrollable_frame.winfo_children():
            widget.destroy()

        # Rebuild list
        for task in self.manager.tasks:
            self.create_task_row(task)

    def create_task_row(self, task):
        row = tk.Frame(self.scrollable_frame, bg=styles.CARD_COLOR, pady=10, padx=10)
        row.pack(fill=tk.X, pady=5)

        # Completion Status
        status_text = "✓" if task.completed else "○"
        status_color = styles.SUCCESS_COLOR if task.completed else styles.SECONDARY_TEXT
        
        status_btn = tk.Button(
            row,
            text=status_text,
            font=styles.SMALL_FONT,
            bg=styles.CARD_COLOR,
            fg=status_color,
            activeforeground=styles.SUCCESS_COLOR,
            relief=tk.FLAT,
            command=lambda: self.toggle_task(task.task_id)
        )
        status_btn.pack(side=tk.LEFT, padx=(0, 10))

        # Task Text
        # Use a string for font modifiers for better compatibility
        font_family = styles.MAIN_FONT[0]
        font_size = styles.MAIN_FONT[1]
        font_style = (font_family, font_size, "overstrike") if task.completed else styles.MAIN_FONT
        text_color = styles.SECONDARY_TEXT if task.completed else styles.TEXT_COLOR
        
        text_label = tk.Label(
            row,
            text=task.text,
            font=font_style,
            bg=styles.CARD_COLOR,
            fg=text_color,
            anchor="w",
            wraplength=280,
            justify=tk.LEFT
        )
        text_label.pack(side=tk.LEFT, fill=tk.X, expand=True)

        # Action Buttons
        del_btn = tk.Button(
            row,
            text="✕",
            font=styles.SMALL_FONT,
            bg=styles.CARD_COLOR,
            fg=styles.DELETE_COLOR,
            activeforeground=styles.DELETE_COLOR,
            relief=tk.FLAT,
            command=lambda: self.delete_task(task.task_id)
        )
        del_btn.pack(side=tk.RIGHT)

        edit_btn = tk.Button(
            row,
            text="✎",
            font=styles.SMALL_FONT,
            bg=styles.CARD_COLOR,
            fg=styles.EDIT_COLOR,
            activeforeground=styles.EDIT_COLOR,
            relief=tk.FLAT,
            command=lambda: self.edit_task(task.task_id, task.text)
        )
        edit_btn.pack(side=tk.RIGHT, padx=5)

    def toggle_task(self, task_id):
        self.manager.toggle_completed(task_id)
        self.refresh_task_list()

    def edit_task(self, task_id, current_text):
        new_text = simpledialog.askstring("Edit Task", "Update your task:", initialvalue=current_text)
        if new_text and new_text.strip():
            self.manager.update_task(task_id, new_text)
            self.refresh_task_list()

    def delete_task(self, task_id):
        if messagebox.askyesno("Confirm Delete", "Are you sure you want to delete this task?"):
            self.manager.delete_task(task_id)
            self.refresh_task_list()

if __name__ == "__main__":
    root = tk.Tk()
    app = ToDoApp(root)
    root.mainloop()
