# Modern styling constants for To-Do List App

# Colors (Nord-inspired palette)
BG_COLOR = "#2E3440"        # Dark Gray/Blue
CARD_COLOR = "#3B4252"      # Lighter Gray/Blue
TEXT_COLOR = "#ECEFF4"      # Almost White
SECONDARY_TEXT = "#D8DEE9"  # Light Gray
ACCENT_COLOR = "#88C0D0"    # Frost Blue
SUCCESS_COLOR = "#A3BE8C"   # Aurora Green
DELETE_COLOR = "#BF616A"    # Aurora Red
EDIT_COLOR = "#EBCB8B"      # Aurora Yellow

# Fonts
TITLE_FONT = ("Inter", 18, "bold")
MAIN_FONT = ("Inter", 12)
SMALL_FONT = ("Inter", 10)

# Window Configuration
WINDOW_TITLE = "ProTask - To-Do List"
WINDOW_SIZE = "500x700"
