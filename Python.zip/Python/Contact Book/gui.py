import tkinter as tk
from tkinter import ttk, messagebox
from db_manager import DatabaseManager
from validation import validate_phone, validate_email

class ContactApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Premium Contact Book")
        self.root.geometry("800x600")
        self.db = DatabaseManager()
        
        self.selected_contact_id = None
        
        self.setup_styles()
        self.create_widgets()
        self.load_contacts()

    def setup_styles(self):
        style = ttk.Style()
        style.theme_use('clam')
        
        # Color palette
        self.bg_color = "#f0f2f5"
        self.primary_color = "#1a73e8"
        self.text_color = "#202124"
        
        self.root.configure(bg=self.bg_color)
        
        style.configure("TFrame", background=self.bg_color)
        style.configure("TLabel", background=self.bg_color, foreground=self.text_color, font=("Segoe UI", 10))
        style.configure("Header.TLabel", font=("Segoe UI", 16, "bold"), foreground=self.primary_color)
        style.configure("TButton", font=("Segoe UI", 10))
        style.configure("Action.TButton", background=self.primary_color, foreground="white")
        
        style.map("Action.TButton", background=[('active', '#174ea6')])

    def create_widgets(self):
        # Main Container
        main_frame = ttk.Frame(self.root, padding="20")
        main_frame.pack(fill=tk.BOTH, expand=True)

        # Header
        header = ttk.Label(main_frame, text="Contact Manager", style="Header.TLabel")
        header.grid(row=0, column=0, columnspan=2, pady=(0, 20), sticky="w")

        # Left Side - Contact List
        list_frame = ttk.Frame(main_frame)
        list_frame.grid(row=1, column=0, sticky="nsew", padx=(0, 20))
        
        # Search Bar
        search_label = ttk.Label(list_frame, text="Search:")
        search_label.pack(anchor="w", pady=(0, 5))
        self.search_var = tk.StringVar()
        self.search_var.trace_add("write", lambda *args: self.search_contacts())
        search_entry = ttk.Entry(list_frame, textvariable=self.search_var, width=30)
        search_entry.pack(fill=tk.X, pady=(0, 10))

        # Treeview for Contacts
        columns = ("Name", "Phone")
        self.tree = ttk.Treeview(list_frame, columns=columns, show="headings", height=15)
        self.tree.heading("Name", text="Name")
        self.tree.heading("Phone", text="Phone Number")
        self.tree.column("Name", width=150)
        self.tree.column("Phone", width=150)
        self.tree.pack(fill=tk.BOTH, expand=True)
        self.tree.bind("<<TreeviewSelect>>", self.on_contact_select)

        # Right Side - Details/Form
        form_frame = ttk.Frame(main_frame)
        form_frame.grid(row=1, column=1, sticky="nsew")
        
        form_title = ttk.Label(form_frame, text="Contact Details", font=("Segoe UI", 12, "bold"))
        form_title.pack(anchor="w", pady=(0, 15))

        self.create_form_field(form_frame, "Name:", "name")
        self.create_form_field(form_frame, "Phone:", "phone")
        self.create_form_field(form_frame, "Email:", "email")
        self.create_form_field(form_frame, "Address:", "address", is_multiline=True)

        # Buttons
        btn_frame = ttk.Frame(form_frame)
        btn_frame.pack(fill=tk.X, pady=20)

        self.add_btn = ttk.Button(btn_frame, text="Add New", command=self.add_contact, style="Action.TButton")
        self.add_btn.pack(side=tk.LEFT, padx=5)

        self.update_btn = ttk.Button(btn_frame, text="Update", command=self.update_contact, state=tk.DISABLED)
        self.update_btn.pack(side=tk.LEFT, padx=5)

        self.delete_btn = ttk.Button(btn_frame, text="Delete", command=self.delete_contact, state=tk.DISABLED)
        self.delete_btn.pack(side=tk.LEFT, padx=5)

        self.clear_btn = ttk.Button(btn_frame, text="Clear", command=self.clear_form)
        self.clear_btn.pack(side=tk.LEFT, padx=5)

        # Configure weights
        main_frame.columnconfigure(0, weight=1)
        main_frame.columnconfigure(1, weight=1)
        main_frame.rowconfigure(1, weight=1)

    def create_form_field(self, parent, label_text, attr_name, is_multiline=False):
        label = ttk.Label(parent, text=label_text)
        label.pack(anchor="w", pady=(10, 2))
        
        if is_multiline:
            text_widget = tk.Text(parent, height=4, width=30, font=("Segoe UI", 10))
            text_widget.pack(fill=tk.X)
            setattr(self, f"{attr_name}_input", text_widget)
        else:
            entry = ttk.Entry(parent, width=30)
            entry.pack(fill=tk.X)
            setattr(self, f"{attr_name}_input", entry)

    def get_form_data(self):
        data = {
            "name": self.name_input.get().strip(),
            "phone": self.phone_input.get().strip(),
            "email": self.email_input.get().strip(),
            "address": self.address_input.get("1.0", tk.END).strip()
        }
        return data

    def validate_data(self, data):
        if not data["name"]:
            messagebox.showerror("Error", "Name is required!")
            return False
        if not validate_phone(data["phone"]):
            messagebox.showerror("Error", "Invalid phone number! (Use digits, min 7, optional +)")
            return False
        if not validate_email(data["email"]):
            messagebox.showerror("Error", "Invalid email format!")
            return False
        return True

    def load_contacts(self, contacts=None):
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        if contacts is None:
            contacts = self.db.get_all_contacts()
            
        for contact in contacts:
            self.tree.insert("", tk.END, values=(contact[1], contact[2]), iid=contact[0])

    def on_contact_select(self, event):
        selected = self.tree.selection()
        if selected:
            self.selected_contact_id = selected[0]
            contact_data = self.db.search_contacts(self.tree.item(self.selected_contact_id)["values"][0])
            # To be more precise, we should fetch by ID, but our search returns by name/phone.
            # Let's add a get_contact_by_id in db_manager if needed.
            # For now, let's just find the exact match in the full list or fetch by id.
            # Refactored: Fetch by id is safer. 
            # (I'll update db_manager.py with get_contact_by_id)
            self.fill_form_with_selection()
            self.update_btn.config(state=tk.NORMAL)
            self.delete_btn.config(state=tk.NORMAL)
            self.add_btn.config(state=tk.DISABLED)

    def fill_form_with_selection(self):
        # Assuming we have a way to get full data from ID
        # For simplicity, we can fetch all and filter or add a method.
        # Let's use get_all_contacts and filter by ID.
        all_c = self.db.get_all_contacts()
        contact = next((c for c in all_c if str(c[0]) == str(self.selected_contact_id)), None)
        if contact:
            self.clear_form(clear_all=False)
            self.name_input.insert(0, contact[1])
            self.phone_input.insert(0, contact[2])
            self.email_input.insert(0, contact[3] if contact[3] else "")
            self.address_input.insert("1.0", contact[4] if contact[4] else "")

    def add_contact(self):
        data = self.get_form_data()
        if self.validate_data(data):
            self.db.add_contact(data["name"], data["phone"], data["email"], data["address"])
            self.load_contacts()
            self.clear_form()
            messagebox.showinfo("Success", "Contact added successfully!")

    def update_contact(self):
        if self.selected_contact_id:
            data = self.get_form_data()
            if self.validate_data(data):
                self.db.update_contact(self.selected_contact_id, data["name"], data["phone"], data["email"], data["address"])
                self.load_contacts()
                self.clear_form()
                messagebox.showinfo("Success", "Contact updated successfully!")

    def delete_contact(self):
        if self.selected_contact_id:
            if messagebox.askyesno("Confirm", "Are you sure you want to delete this contact?"):
                self.db.delete_contact(self.selected_contact_id)
                self.load_contacts()
                self.clear_form()

    def search_contacts(self):
        query = self.search_var.get()
        results = self.db.search_contacts(query)
        self.load_contacts(results)

    def clear_form(self, clear_all=True):
        self.name_input.delete(0, tk.END)
        self.phone_input.delete(0, tk.END)
        self.email_input.delete(0, tk.END)
        self.address_input.delete("1.0", tk.END)
        if clear_all:
            self.selected_contact_id = None
            self.tree.selection_remove(self.tree.selection())
            self.update_btn.config(state=tk.DISABLED)
            self.delete_btn.config(state=tk.DISABLED)
            self.add_btn.config(state=tk.NORMAL)

if __name__ == "__main__":
    root = tk.Tk()
    app = ContactApp(root)
    root.mainloop()
