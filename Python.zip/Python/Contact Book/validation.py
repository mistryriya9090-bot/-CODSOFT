import re

def validate_phone(phone):
    # Regex for a basic phone number (7-15 digits, optional +)
    pattern = r"^\+?\d{7,15}$"
    return re.match(pattern, phone) is not None

def validate_email(email):
    if not email:
        return True  # Email is optional
    pattern = r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$"
    return re.match(pattern, email) is not None
