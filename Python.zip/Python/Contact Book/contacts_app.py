import tkinter as tk
from gui import ContactApp

def main():
    root = tk.Tk()
    app = ContactApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
