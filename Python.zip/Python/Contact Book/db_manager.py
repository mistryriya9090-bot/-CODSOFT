import sqlite3
import os

class DatabaseManager:
    def __init__(self, db_name="contacts.db"):
        self.db_name = db_name
        self.init_db()

    def get_connection(self):
        return sqlite3.connect(self.db_name)

    def init_db(self):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS contacts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    phone TEXT NOT NULL,
                    email TEXT,
                    address TEXT
                )
            """)
            conn.commit()

    def add_contact(self, name, phone, email, address):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO contacts (name, phone, email, address)
                VALUES (?, ?, ?, ?)
            """, (name, phone, email, address))
            conn.commit()
            return cursor.lastrowid

    def get_all_contacts(self):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM contacts ORDER BY name ASC")
            return cursor.fetchall()

    def search_contacts(self, query):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            # Search by name or phone
            cursor.execute("""
                SELECT * FROM contacts 
                WHERE name LIKE ? OR phone LIKE ?
                ORDER BY name ASC
            """, (f"%{query}%", f"%{query}%"))
            return cursor.fetchall()

    def update_contact(self, contact_id, name, phone, email, address):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE contacts
                SET name = ?, phone = ?, email = ?, address = ?
                WHERE id = ?
            """, (name, phone, email, address, contact_id))
            conn.commit()

    def delete_contact(self, contact_id):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM contacts WHERE id = ?", (contact_id,))
            conn.commit()
