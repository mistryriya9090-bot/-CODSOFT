import random

class GameLogic:
    CHOICES = ["rock", "paper", "scissors"]
    
    def __init__(self):
        self.user_score = 0
        self.computer_score = 0
        self.ties = 0

    def get_computer_choice(self):
        return random.choice(self.CHOICES)

    def determine_winner(self, user_choice, computer_choice):
        """
        Determines the winner of a single round.
        Returns: 'user', 'computer', or 'tie'
        """
        if user_choice == computer_choice:
            self.ties += 1
            return "tie"
        
        # Win conditions for user
        win_conditions = {
            "rock": "scissors",
            "paper": "rock",
            "scissors": "paper"
        }
        
        if win_conditions[user_choice] == computer_choice:
            self.user_score += 1
            return "user"
        else:
            self.computer_score += 1
            return "computer"

    def reset_scores(self):
        self.user_score = 0
        self.computer_score = 0
        self.ties = 0
