try:
    import tkinter
    print("tkinter is available")
    root = tkinter.Tk()
    print("Tkinter root created successfully")
    root.destroy()
except Exception as e:
    print(f"Error with tkinter: {e}")
