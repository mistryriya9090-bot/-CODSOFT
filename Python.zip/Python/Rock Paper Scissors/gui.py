import tkinter as tk
from tkinter import messagebox
from game_logic import GameLogic

class RockPaperScissorsGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Rock Paper Scissors - Premium Edition")
        self.root.geometry("500x600")
        self.root.configure(bg="#2c3e50")
        
        self.game = GameLogic()
        
        # Initialize UI elements to None for linting/clarity
        self.user_score_label = None
        self.comp_score_label = None
        self.result_label = None
        self.rock_btn = None
        self.paper_btn = None
        self.scissors_btn = None
        self.reset_btn = None
        self.exit_btn = None
        
        self.setup_ui()

    def setup_ui(self):
        # Header
        title_label = tk.Label(self.root, text="ROCK PAPER SCISSORS", 
                              font=("Arial", 24, "bold"), bg="#2c3e50", fg="#ecf0f1", pady=20)
        title_label.pack()

        # Score Frame
        score_frame = tk.Frame(self.root, bg="#2c3e50")
        score_frame.pack(pady=10)
        
        self.user_score_label = tk.Label(score_frame, text=f"YOU: {self.game.user_score}", 
                                       font=("Arial", 16), bg="#2c3e50", fg="#2ecc71", padx=20)
        self.user_score_label.grid(row=0, column=0)
        
        self.comp_score_label = tk.Label(score_frame, text=f"COMP: {self.game.computer_score}", 
                                       font=("Arial", 16), bg="#2c3e50", fg="#e74c3c", padx=20)
        self.comp_score_label.grid(row=0, column=1)

        # Result Display Area
        self.result_label = tk.Label(self.root, text="CHOOSE YOUR WEAPON!", 
                                    font=("Arial", 14, "italic"), bg="#34495e", fg="#ecf0f1", 
                                    width=35, height=5, relief="flat", pady=10)
        self.result_label.pack(pady=30)

        # Choice Frame
        choice_frame = tk.Frame(self.root, bg="#2c3e50")
        choice_frame.pack(pady=20)

        btn_style = {
            "font": ("Arial", 12, "bold"),
            "width": 12,
            "height": 2,
            "relief": "flat",
            "cursor": "hand2"
        }

        self.rock_btn = tk.Button(choice_frame, text="🪨 ROCK", bg="#95a5a6", fg="white", 
                                 command=lambda: self.play("rock"), **btn_style)
        self.rock_btn.grid(row=0, column=0, padx=10)

        self.paper_btn = tk.Button(choice_frame, text="📄 PAPER", bg="#3498db", fg="white", 
                                  command=lambda: self.play("paper"), **btn_style)
        self.paper_btn.grid(row=0, column=1, padx=10)

        self.scissors_btn = tk.Button(choice_frame, text="✂️ SCISSORS", bg="#f1c40f", fg="black", 
                                     command=lambda: self.play("scissors"), **btn_style)
        self.scissors_btn.grid(row=0, column=2, padx=10)

        # Control Frame
        control_frame = tk.Frame(self.root, bg="#2c3e50")
        control_frame.pack(side="bottom", pady=40)

        self.reset_btn = tk.Button(control_frame, text="Reset Scores", font=("Arial", 10), 
                                  bg="#e67e22", fg="white", relief="flat", command=self.reset_game)
        self.reset_btn.pack(side="left", padx=10)

        self.exit_btn = tk.Button(control_frame, text="Exit Game", font=("Arial", 10), 
                                 bg="#c0392b", fg="white", relief="flat", command=self.root.quit)
        self.exit_btn.pack(side="left", padx=10)

    def play(self, user_choice):
        if not user_choice:
            return

        computer_choice = self.game.get_computer_choice()
        result = self.game.determine_winner(user_choice, computer_choice)
        
        print(f"\nYour Choice:     {user_choice.capitalize()}")
        print(f"Computer Choice: {computer_choice.capitalize()}")
        
        result_text = f"YOU chose: {user_choice.upper()}\nCOMP chose: {computer_choice.upper()}\n\n"
        
        if result == "tie":
            result_text += "IT'S A TIE! 🤝"
            self.result_label.config(fg="#bdc3c7")
        elif result == "user":
            result_text += "YOU WIN! 🎉"
            self.result_label.config(fg="#2ecc71")
        else:
            result_text += "COMPUTER WINS! 🤖"
            self.result_label.config(fg="#e74c3c")
            
        self.result_label.config(text=result_text)
        self.update_scores()

    def update_scores(self):
        self.user_score_label.config(text=f"YOU: {self.game.user_score}")
        self.comp_score_label.config(text=f"COMP: {self.game.computer_score}")

    def reset_game(self):
        if messagebox.askyesno("Reset", "Are you sure you want to reset the scores?"):
            self.game.reset_scores()
            self.update_scores()
            self.result_label.config(text="SCORES RESET!\nCHOOSE YOUR WEAPON!", fg="#ecf0f1")

if __name__ == "__main__":
    try:
        root = tk.Tk()
        app = RockPaperScissorsGUI(root)
        root.mainloop()
    except Exception as e:
        print(f"Error starting GUI: {e}")
        import traceback
        traceback.print_exc()
        input("Press Enter to exit...")
