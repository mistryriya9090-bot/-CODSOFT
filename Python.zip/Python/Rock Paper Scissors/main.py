import sys
from game_logic import GameLogic

def print_banner():
    print("\n" + "="*40)
    print("      ROCK PAPER SCISSORS - CLI")
    print("="*40 + "\n")

def get_user_choice():
    while True:
        choice = input("Enter Choice (Rock/Paper/Scissors) or 'Q' to Quit: ").lower().strip()
        if choice in ['rock', 'paper', 'scissors', 'q', 'quit']:
            return choice
        print("Invalid choice. Please try again.")

def main():
    game = GameLogic()
    print_banner()
    
    while True:
        user_choice = get_user_choice()
        
        if user_choice in ['q', 'quit']:
            print("\nFinal Scores:")
            print(f"  User:     {game.user_score}")
            print(f"  Computer: {game.computer_score}")
            print(f"  Ties:     {game.ties}")
            print("\nThanks for playing!")
            break
            
        if not user_choice:
            continue
            
        computer_choice = game.get_computer_choice()
        result = game.determine_winner(user_choice, computer_choice)
        
        print(f"\nYour Choice:     {user_choice.capitalize()}")
        print(f"Computer Choice: {computer_choice.capitalize()}")
        
        if result == "tie":
            print(">> It's a TIE!")
        elif result == "user":
            print(">> YOU WIN this round! 🎉")
        else:
            print(">> COMPUTER WINS this round! 🤖")
            
        print(f"\nScore: User {game.user_score} - Computer {game.computer_score}")
        print("-" * 30)
        
        play_again = input("\nPlay another round? (y/n): ").lower().strip()
        if play_again != 'y':
            print("\nFinal Scores:")
            print(f"  User:     {game.user_score}")
            print(f"  Computer: {game.computer_score}")
            print(f"  Ties:     {game.ties}")
            print("\nThanks for playing!")
            break

if __name__ == "__main__":
    main()
