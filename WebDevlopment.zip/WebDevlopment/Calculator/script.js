document.addEventListener('DOMContentLoaded', () => {
    const previousOperandTextElement = document.getElementById('previous-operand');
    const currentOperandTextElement = document.getElementById('current-operand');
    const buttons = document.querySelectorAll('.btn');

    let currentOperand = '0';
    let previousOperand = '';
    let operation = undefined;
    let shouldResetScreen = false;

    function updateDisplay() {
        currentOperandTextElement.innerText = formatNumber(currentOperand);
        if (operation != null) {
            previousOperandTextElement.innerText = `${formatNumber(previousOperand)} ${getOperationSymbol(operation)}`;
        } else {
            previousOperandTextElement.innerText = '';
        }
    }

    function formatNumber(numberStr) {
        if (numberStr === 'Error') return numberStr;
        if (numberStr === '' || numberStr === '-') return numberStr;
        
        const stringNumber = numberStr.toString();
        const integerDigits = parseFloat(stringNumber.split('.')[0]);
        const decimalDigits = stringNumber.split('.')[1];
        
        let integerDisplay;
        if (isNaN(integerDigits)) {
            integerDisplay = '';
        } else {
            integerDisplay = integerDigits.toLocaleString('en', { maximumFractionDigits: 0 });
        }
        
        if (decimalDigits != null) {
            return `${integerDisplay}.${decimalDigits}`;
        } else {
            return integerDisplay;
        }
    }

    function getOperationSymbol(op) {
        switch (op) {
            case 'add': return '+';
            case 'subtract': return '−';
            case 'multiply': return '×';
            case 'divide': return '÷';
            default: return '';
        }
    }

    function clear() {
        currentOperand = '0';
        previousOperand = '';
        operation = undefined;
    }

    function deleteNumber() {
        if (currentOperand === 'Error') {
            clear();
            return;
        }
        if (currentOperand.length === 1 || (currentOperand.length === 2 && currentOperand.startsWith('-'))) {
            currentOperand = '0';
        } else {
            currentOperand = currentOperand.toString().slice(0, -1);
        }
    }

    function appendNumber(number) {
        if (currentOperand === 'Error') clear();
        if (number === '.' && currentOperand.includes('.')) return;
        if (shouldResetScreen) {
            currentOperand = number === '.' ? '0.' : number;
            shouldResetScreen = false;
        } else {
            if (currentOperand === '0' && number !== '.') {
                currentOperand = number;
            } else {
                currentOperand = currentOperand.toString() + number.toString();
            }
        }
        
        // Prevent too long numbers
        if (currentOperand.length > 15) {
            currentOperand = currentOperand.slice(0, 15);
        }
    }

    function calculatePercentage() {
        if (currentOperand === 'Error') return;
        const current = parseFloat(currentOperand);
        if (isNaN(current)) return;
        currentOperand = (current / 100).toString();
    }

    function chooseOperation(op) {
        if (currentOperand === 'Error') clear();
        if (currentOperand === '') return;
        if (previousOperand !== '') {
            compute();
        }
        operation = op;
        previousOperand = currentOperand;
        currentOperand = '';
    }

    function compute() {
        let computation;
        const prev = parseFloat(previousOperand);
        const current = parseFloat(currentOperand);
        
        if (isNaN(prev) || isNaN(current)) return;
        
        switch (operation) {
            case 'add':
                computation = prev + current;
                break;
            case 'subtract':
                computation = prev - current;
                break;
            case 'multiply':
                computation = prev * current;
                break;
            case 'divide':
                if (current === 0) {
                    currentOperand = 'Error';
                    operation = undefined;
                    previousOperand = '';
                    return;
                }
                computation = prev / current;
                break;
            default:
                return;
        }
        
        currentOperand = computation.toString().length > 15 
            ? computation.toPrecision(12).replace(/\.?0+$/, '') 
            : computation.toString();
        operation = undefined;
        previousOperand = '';
        shouldResetScreen = true;
    }

    buttons.forEach(button => {
        button.addEventListener('click', () => {
            if (button.dataset.number !== undefined) {
                appendNumber(button.dataset.number);
            } else if (button.dataset.action !== undefined) {
                const action = button.dataset.action;
                
                switch(action) {
                    case 'clear':
                        clear();
                        break;
                    case 'delete':
                        deleteNumber();
                        break;
                    case 'percent':
                        calculatePercentage();
                        break;
                    case 'add':
                    case 'subtract':
                    case 'multiply':
                    case 'divide':
                        chooseOperation(action);
                        break;
                    case 'calculate':
                        compute();
                        break;
                }
            }
            updateDisplay();
            
            // Highlight active operator if any
            document.querySelectorAll('.btn-operator').forEach(btn => btn.classList.remove('active'));
            if (operation) {
                const activeBtn = document.querySelector(`.btn-operator[data-action="${operation}"]`);
                if (activeBtn) activeBtn.classList.add('active');
            }
            // remove active class if we just pressed equals
            if(button.dataset.action === 'calculate') {
                 document.querySelectorAll('.btn-operator').forEach(btn => btn.classList.remove('active'));
            }
        });
    });

    // Keyboard support
    document.addEventListener('keydown', e => {
        if (e.key >= '0' && e.key <= '9') appendNumber(e.key);
        if (e.key === '.') appendNumber('.');
        if (e.key === '=' || e.key === 'Enter') compute();
        if (e.key === 'Backspace') deleteNumber();
        if (e.key === 'Escape') clear();
        if (e.key === '+' || e.key === '-') chooseOperation(e.key === '+' ? 'add' : 'subtract');
        if (e.key === '*' || e.key === '/') {
            e.preventDefault(); // Prevent default browser behavior for `/`
            chooseOperation(e.key === '*' ? 'multiply' : 'divide');
        }
        if (e.key === '%') calculatePercentage();
        updateDisplay();
    });

    updateDisplay();
});
